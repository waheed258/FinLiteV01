$(document).ready(function() {
    $(".populate").select2();
});

